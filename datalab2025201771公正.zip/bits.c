/* WARNING: Do not include any other libraries here,
 * otherwise you will get an error while running test.py
 * You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.
 *
 * Using printf will interfere with our script capturing the execution results.
 * At this point, you can only test correctness with ./btest.
 * After confirming everything is correct in ./btest, remove the printf
 * and run the complete tests with test.py.
 */

 /*
 * bitAnd - x & y using only ~ and |
 * Example: bitAnd(4, 5) = 4
 * Legal ops: ~ |
 * Max ops: 7
 * Difficulty: 1
 */
int bitAnd(int x, int y) {
    return ~(~x | ~y);
}

/*
 * bitXor - x ^ y using only ~ and &
 *   Example: bitXor(4, 5) = 1
 *   Legal ops: ~ &
 *   Max ops: 7
 *   Difficulty: 1
 */
int bitXor(int x, int y) {
    return ~(x & y) & ~(~x & ~y);
}

/*
 * samesign - Determines if two integers have the same sign.
 *   0 is not positive, nor negative
 *   Example: samesign(0, 1) = 0, samesign(0, 0) = 1
 *            samesign(-4, -5) = 1, samesign(-4, 5) = 0
 *   Legal ops: >> << ! ^ && if else &
 *   Max ops: 12
 *   Difficulty: 2
 *
 * Parameters:
 *   x - The first integer.
 *   y - The second integer.
 *
 * Returns:
 *   1 if x and y have the same sign , 0 otherwise.
 */
int samesign(int x, int y) {
    return !(((x >> 31) ^ (y >> 31)) ^ (!!x ^ !!y));
}

/*
 * logtwo - Calculate the base-2 logarithm of a positive integer using bit
 *   shifting. (Think about bitCount)
 *   Note: You may assume that v > 0
 *   Example: logtwo(32) = 5
 *   Legal ops: > < >> << |
 *   Max ops: 25
 *   Difficulty: 4
 */
int logtwo(int v) {
    int b16 = (v >> 16) > 0;
    int r = b16;
    v = v >> (b16 << 4);
    int b8 = (v >> 8) > 0;
    r = (r << 1) | b8;
    v = v >> (b8 << 3);
    int b4 = (v >> 4) > 0;
    r = (r << 1) | b4;
    v = v >> (b4 << 2);
    int b2 = (v >> 2) > 0;
    r = (r << 1) | b2;
    v = v >> (b2 << 1);
    int b1 = v > 1;
    return (r << 1) | b1;
}

/*
 *  byteSwap - swaps the nth byte and the mth byte
 *    Examples: byteSwap(0x12345678, 1, 3) = 0x56341278
 *              byteSwap(0xDEADBEEF, 0, 2) = 0xDEEFBEAD
 *    Note: You may assume that 0 <= n <= 3, 0 <= m <= 3
 *    Legal ops: ! ~ & ^ | + << >>
 *    Max ops: 17
 *    Difficulty: 2
 */
int byteSwap(int x, int n, int m) {
    int ns = n << 3;
    int ms = m << 3;
    int byteN = (x >> ns) & 0xff;
    int byteM = (x >> ms) & 0xff;
    int diff = byteN ^ byteM;
    return x ^ (diff << ns) ^ (diff << ms);
}

/*
 * reverse - Reverse the bit order of a 32-bit unsigned integer.
 *   Example: reverse(0xFFFF0000) = 0x0000FFFF reverse(0x80000000)=0x1 reverse(0xA0000000)=0x5
 *   Note: You may assume that an unsigned integer is 32 bits long.
 *   Legal ops: << | & - + >> for while ! ~ (You can define unsigned in this function)
 *   Max ops: 30
 *   Difficulty: 3
 */
unsigned reverse(unsigned v) {
    unsigned result = 0;
    int remaining = 32;
    while (remaining) {
        result = (result << 1) | (v & 1u);
        v = v >> 1;
        remaining = remaining - 1;
    }
    return result;
}

/*
 * logicalShift - shift x to the right by n, using a logical shift
 *   Examples: logicalShift(0x87654321,4) = 0x08765432
 *   Note: You can assume that 0 <= n <= 31
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Difficulty: 3
 */
int logicalShift(int x, int n) {
    int signMask = ~(((1 << 31) >> n) << 1);
    return (x >> n) & signMask;
}

/*
 * leftBitCount - returns count of number of consective 1's in left-hand (most) end of word.
 *   Examples: leftBitCount(-1) = 32, leftBitCount(0xFFF0F0F0) = 12,
 *             leftBitCount(0xFE00FF0F) = 7
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 50
 *   Difficulty: 4
 */
int leftBitCount(int x) {
    int b16 = !(~(x >> 16));
    int count = b16 << 4;
    x = x << (b16 << 4);
    int b8 = !(~(x >> 24));
    count = count + (b8 << 3);
    x = x << (b8 << 3);
    int b4 = !(~(x >> 28));
    count = count + (b4 << 2);
    x = x << (b4 << 2);
    int b2 = !(~(x >> 30));
    count = count + (b2 << 1);
    x = x << (b2 << 1);
    int b1 = !(~(x >> 31));
    count = count + b1;
    x = x << b1;
    return count + ((x >> 31) & 1);
}

/*
 * float_i2f - Return bit-level equivalent of expression (float) x
 *   Result is returned as unsigned int, but it is to be interpreted as
 *   the bit-level representation of a single-precision floating point values.
 *   Legal ops: if else while for & | ~ + - >> << < > ! ==
 *   Max ops: 30
 *   Difficulty: 4
 */
unsigned float_i2f(int x) {
    unsigned sign = 0;
    unsigned ux = x;
    unsigned significand;
    unsigned exponent;
    int msb = 31;
    int shift;

    if (x < 0) {
        sign = 0x80000000u;
        ux = ~ux + 1u;
    }
    if (ux == 0u) {
        return 0u;
    }
    while ((ux >> msb) == 0u) {
        msb = msb - 1;
    }
    exponent = msb + 127u;
    if (msb <= 23) {
        significand = ux << (23 - msb);
    } else {
        shift = msb - 23;
        significand = (ux + (1u << (shift - 1)) + ~0u + ((ux >> shift) & 1u)) >> shift;
        if (significand & 0x01000000u) {
            significand = significand >> 1;
            exponent = exponent + 1u;
        }
    }
    return sign | (exponent << 23) | (significand & 0x007fffffu);
}

/*
 * floatScale2 - Return bit-level equivalent of expression 2*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: & >> << | if > < >= <= ! ~ else + ==
 *   Max ops: 30
 *   Difficulty: 4
 */
unsigned floatScale2(unsigned uf) {
    unsigned sign = uf & 0x80000000u;
    unsigned exponent = (uf >> 23) & 0xffu;
    unsigned fraction = uf & 0x007fffffu;
    if (exponent == 0xffu) {
        return uf;
    }
    if (exponent == 0u) {
        return sign | (fraction << 1);
    }
    if (exponent == 0xfeu) {
        return sign | 0x7f800000u;
    }
    return sign | ((exponent + 1u) << 23) | fraction;
}

/*
 * float64_f2i - Convert a 64-bit IEEE 754 floating-point number to a 32-bit signed integer.
 *   The conversion rounds towards zero.
 *   Note: Assumes IEEE 754 representation and standard two's complement integer format.
 *   Parameters:
 *     uf1 - The lower 32 bits of the 64-bit floating-point number.
 *     uf2 - The higher 32 bits of the 64-bit floating-point number.
 *   Returns:
 *     The converted integer value, or 0x80000000 on overflow, or 0 on underflow.
 *   Legal ops: >> << | & ~ ! + - > < >= <= if else
 *   Max ops: 60
 *   Difficulty: 3
 */
int float64_f2i(unsigned uf1, unsigned uf2) {
    unsigned exponent = (uf2 >> 20) & 0x7ffu;
    unsigned fractionHigh = uf2 & 0x000fffffu;
    unsigned significandHigh;
    unsigned magnitude;
    unsigned shift;
    int sign = uf2 >> 31;
    int e;
    int value;

    if (exponent > 0x7feu) {
        return ~0x7fffffff;
    }
    if (!exponent) {
        return 0;
    }
    if (exponent < 1023u) {
        return 0;
    }
    e = exponent - 1023u;
    if (e >= 31) {
        return ~0x7fffffff;
    }
    significandHigh = fractionHigh | 0x00100000u;
    if (e <= 20) {
        magnitude = significandHigh >> (20 - e);
    } else {
        shift = 52u - e;
        magnitude = (significandHigh << (32u - shift)) | (uf1 >> shift);
    }
    value = magnitude;
    if (sign) {
        return -value;
    }
    return value;
}

/*
 * floatPower2 - Return bit-level equivalent of the expression 2.0^x
 *   (2.0 raised to the power x) for any 32-bit integer x.
 *
 *   The unsigned value that is returned should have the identical bit
 *   representation as the single-precision floating-point number 2.0^x.
 *   If the result is too small to be represented as a denorm, return
 *   0. If too large, return +INF.
 *
 *   Legal ops: < > <= >= << >> + - & | ~ ! if else &&
 *   Max ops: 30
 *   Difficulty: 4
 */
unsigned floatPower2(int x) {
    unsigned exponent;
    if (x > 127) {
        return 0x7f800000u;
    }
    if (x >= -126) {
        exponent = x + 127;
        return exponent << 23;
    }
    if (x >= -149) {
        return 1u << (x + 149);
    }
    return 0u;
}
